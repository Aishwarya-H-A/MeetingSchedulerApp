package com.example.meetingschedulerapp;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Objects;

public class add_meeting extends Fragment {

    EditText date, time, agenda;
    CalendarView calendar;
    Button b1, b2;
    Database DB;

    @Nullable
    @Override

    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_meeting, container,false);
        date = view.findViewById(R.id.editTextDate4);
        time = view.findViewById(R.id.editTextTime);
        agenda = view.findViewById(R.id.editTextTextPersonName);
        b1 = view.findViewById(R.id.button);
        b2 = view.findViewById(R.id.button3);
        calendar = view.findViewById(R.id.calendarView);
        DB = new Database(getActivity());
        calendar.setVisibility(View.INVISIBLE);

        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeKeyBoard();
                calendar.setVisibility(View.VISIBLE);
                calendar.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
                    @Override
                    public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                        String d = dayOfMonth + "-" + (month+1) + "-" + year;
                        date.setText(d);
                        calendar.setVisibility(View.INVISIBLE);
                    }
                });
            }
        });

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mdate,mTime,mAgenda;
                mdate = date.getText().toString();
                mTime = time.getText().toString();
                mAgenda = agenda.getText().toString();

                boolean insert = DB.insertdata(mdate, mTime, mAgenda);
                if (insert==true){
                    Toast.makeText(getActivity(),"Meeting Added", Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(getActivity(),"Meeting NOT Added.",Toast.LENGTH_SHORT).show();
            }
        });

        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String mdate,mTime,mAgenda;
                mdate = date.getText().toString();
                mTime = time.getText().toString();
                mAgenda = agenda.getText().toString();

                boolean insert = DB.updatedata(mdate, mTime, mAgenda);
                if (insert==true){
                    Toast.makeText(getActivity(),"Meeting Updated", Toast.LENGTH_SHORT).show();
                }
                else
                    Toast.makeText(getActivity(),"Meeting NOT updated.",Toast.LENGTH_SHORT).show();
                }
        });

        return view;
    }

    private void closeKeyBoard(){
        View  view = requireActivity().getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager)
                    getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }

    }
}
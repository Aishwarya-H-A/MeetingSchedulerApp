package com.example.meetingschedulerapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.os.Bundle;

import com.google.android.material.tabs.TabLayout;

public class MainActivity extends AppCompatActivity {

    TabLayout tabLayout;
    ViewPager viewPager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tabLayout = findViewById(R.id.tabLayout);
        viewPager = findViewById(R.id.viewPager);
        Database DB = new Database(this);
        tabLayout.setupWithViewPager(viewPager);
        adapter adapter = new adapter(getSupportFragmentManager(), FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        adapter.addFragment(new add_meeting(), "Add Meeting");
        adapter.addFragment(new view_meetings(), "View Meetings");
        adapter.addFragment(new delete_meeting(), "Delete Meeting");
        viewPager.setAdapter(adapter);
    }
}
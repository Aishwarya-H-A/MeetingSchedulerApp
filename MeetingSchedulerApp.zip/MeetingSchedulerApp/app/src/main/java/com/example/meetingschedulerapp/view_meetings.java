package com.example.meetingschedulerapp;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.database.Cursor;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.TextView;
import android.widget.Toast;

public class view_meetings extends Fragment {
    TextView date;
    CalendarView calender;
    Button b;
    Database DB;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_view_meetings,container,false);
        date = view.findViewById(R.id.editTextDate);
        calender = view.findViewById(R.id.calendarView2);
        b = view.findViewById(R.id.button2);
        DB = new Database(getActivity());

        calender.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                String d = dayOfMonth + "-" + (month+1) + "-" + year;
                date.setText(d);
            }
        });

        b.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("Range")
            @Override
            public void onClick(View v) {
                String d1 = date.getText().toString();
                StringBuffer result = new StringBuffer();
                Cursor c = DB.viewdata(d1);
                int count = c.getCount();
                c.moveToFirst();
                if (count == 0) {
                    Toast.makeText(getActivity(), "No Meetings on This Day", Toast.LENGTH_LONG).show();
                    return;
                }
                while (c.moveToNext()) {
                    result.append("Date: " + c.getString(0) + "\n");
                    result.append("Time: " + c.getString(1) + "\n");
                    result.append("Agenda: " + c.getString(2) + "\n");
                }

                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setCancelable(true);
                builder.setTitle("User Entries");
                builder.setMessage(result.toString());
                builder.show();
            }
        });
        return view;
    }
}
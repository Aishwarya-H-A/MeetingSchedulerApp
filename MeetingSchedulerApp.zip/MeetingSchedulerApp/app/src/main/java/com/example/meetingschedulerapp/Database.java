package com.example.meetingschedulerapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Database extends SQLiteOpenHelper {
    public Database(Context context) {
        super(context, "meetings.db", null, 1);
    }


    @Override
    public void onCreate(SQLiteDatabase DB) {
        DB.execSQL("create table meeting(date TEXT , time TEXT, agenda TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase DB, int oldVersion, int newVersion) {
        DB.execSQL("drop table if exists meeting");
    }

    public boolean insertdata(String date, String time, String agenda) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("date", date);
        contentValues.put("time", time);
        contentValues.put("agenda", agenda);
        long result = db.insert("meeting", null, contentValues);
        return result != -1;
    }

    public boolean updatedata(String date, String time, String agenda) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("time", time.toString());
        contentValues.put("agenda", agenda);
        Cursor cursor = db.rawQuery("select * from meeting where date=? and time=?", new String[] {date, time});
        if (cursor.getCount()>0) {
            long result = db.update("meeting", contentValues, "date=? and time=?", new String[] {date, time});
            return result != -1;
        }
        else {
            return false;
        }
    }

    public boolean deletedata(String date, String time) {
        SQLiteDatabase db = this.getWritableDatabase();
        Cursor cursor = db.rawQuery("select * from meeting where date=? and time=?", new String[] {date, time});
        if (cursor.getCount()>0) {
            long result = db.delete("meeting", "date=? and time=?", new String[] {date, time});
            return result != -1;
        }
        else {
            return false;
        }
    }

    public Cursor viewdata(String date) {
        SQLiteDatabase db = this.getWritableDatabase();
        return db.rawQuery("select * from meeting where date=?", new String[] {date.toString()});
    }
}

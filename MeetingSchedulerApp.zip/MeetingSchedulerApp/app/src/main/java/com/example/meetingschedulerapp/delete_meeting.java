package com.example.meetingschedulerapp;

import android.content.Context;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.Toast;

public class delete_meeting extends Fragment {

    Button b;
    EditText date, time;
    Database DB;
    CalendarView calendarView;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_delete_meeting,container,false);
        date = view.findViewById(R.id.editTextDate10);
        time = view.findViewById(R.id.editTextTime11);
        b = view.findViewById(R.id.button10);
        DB = new Database(getActivity());
        calendarView = view.findViewById(R.id.calendarView3);
        calendarView.setVisibility(View.INVISIBLE);

        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeKeyBoard();
                calendarView.setVisibility(View.VISIBLE);
                calendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
                    @Override
                    public void onSelectedDayChange(@NonNull CalendarView view, int year, int month, int dayOfMonth) {
                        String d = dayOfMonth + "-" + (month+1) + "-" + year;
                        date.setText(d);
                        calendarView.setVisibility(View.INVISIBLE);
                    }
                });
            }
        });

        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String d1 = date.getText().toString();
                String t1 = time.getText().toString();
                boolean insert = DB.deletedata(d1, t1);
                if (insert) {
                    Toast.makeText(getActivity(), "Meeting Deleted", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(getActivity(), "Meeting NOT Deleted.", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return view;
    }

    private void closeKeyBoard(){
        View  view = requireActivity().getCurrentFocus();
        if (view != null) {
            InputMethodManager imm = (InputMethodManager)
                    getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }

    }
}